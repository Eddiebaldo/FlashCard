package com.example.eddiebaldo.audiocard;



public class OnClickListener2 {


stop.setOnClickListener(new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            myAudioRecorder.stop();
            myAudioRecorder.release();
            myAudioRecorder = null;
            record.setEnabled(true);
            stop.setEnabled(false);
            play.setEnabled(true);
            Toast.makeText(getApplicationContext(), "Audio Recorder stopped", Toast.LENGTH_LONG).show();
        }
    });

}
