package com.example.eddiebaldo.audiocard;
import android.os.Environment;

public class OutputFile {

    String outputFile = Environment.getExternalStorageDirectory().getAbsolutePath() + "/recording.3gp";

}
