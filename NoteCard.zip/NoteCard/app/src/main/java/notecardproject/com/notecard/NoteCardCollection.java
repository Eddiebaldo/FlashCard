package notecardproject.com.notecard;

import java.util.*;

public class NoteCardCollection {
    public ArrayList<NoteCardClass> cards = new ArrayList<NoteCardClass>(5);
}
