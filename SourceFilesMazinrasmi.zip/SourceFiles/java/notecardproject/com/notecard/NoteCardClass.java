package notecardproject.com.notecard;

public class NoteCardClass {
    public String question;
    public String answer;
    public NoteCardClass(String question, String answer){
        this.question = question;
        this.answer = answer;
    }
}
